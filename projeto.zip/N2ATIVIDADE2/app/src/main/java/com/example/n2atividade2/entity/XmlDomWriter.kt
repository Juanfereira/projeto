    package com.example.n2atividade2.entity

    import android.util.Log
    import org.w3c.dom.Document
    import org.w3c.dom.Element
    import javax.xml.parsers.DocumentBuilder
    import javax.xml.parsers.DocumentBuilderFactory
    import javax.xml.transform.OutputKeys
    import javax.xml.transform.Transformer
    import javax.xml.transform.TransformerFactory
    import javax.xml.transform.dom.DOMSource
    import javax.xml.transform.stream.StreamResult
    import java.io.File
    import java.io.StringWriter

    fun main(args: Array<String>) {
        val docBuilder: DocumentBuilder = DocumentBuilderFactory.newInstance().newDocumentBuilder()
        val doc: Document = docBuilder.newDocument()

        val rootElement: Element = doc.createElement("gpx")
        rootElement.setAttribute("xmlns:xsi", "http://www.w3.org/2001/XMLSchema-instance")
        rootElement.setAttribute("xmlns", "http://www.topografix.com/GPX/1/1")

        val metadata: Element =  doc.createElement("metadata")
        val time: Element =  doc.createElement("time")
        time.appendChild(doc.createTextNode("2023-05-25T20:28:42Z"))
        metadata.appendChild(time)

        val trk: Element = doc.createElement("trk")
        val name: Element = doc.createElement("name")
        val type: Element = doc.createElement("type")
        name.appendChild(doc.createTextNode("Caminhada"))
        type.appendChild(doc.createTextNode("1"))
        trk.appendChild(name)
        trk.appendChild(type)

        doc.appendChild(rootElement)

        val transformer: Transformer = TransformerFactory.newInstance().newTransformer()

        transformer.setOutputProperty(OutputKeys.INDENT, "yes")
        transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2")

        val source = DOMSource(doc)
        val result = StreamResult(System.out)

        transformer.transform(source, result)

        Log.d("OLHA AQI", "${doc.toString()}")

    }